/**************************************
* "uart.h":                           *
* Header file for Mega32 UART driver. *
* Henning Hargaard, 29.1.2015          *
***************************************/ 
void InitUART();
char ReadChar();
void SendChar(char Ch);
/**************************************/
