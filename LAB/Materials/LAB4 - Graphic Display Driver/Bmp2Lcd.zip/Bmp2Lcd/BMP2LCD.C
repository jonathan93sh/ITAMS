/***************************************************************************
 bmp2lcd: BMP coded graphic file to 128X64 LCD module C source converter.
 Copyright (C) 2003 shinymetal@libero.it
			**********************
 bmp2lcd converts from a 1bpp BMP coded image into a C source code
 composed of two arrays, one for the left half and the other one for
 the right half of the LCD module.
 As an additional option, you can specify the array name ( defaults to
 Splash ).
 If you find any bug or you have some suggestions, feel free to
 write me at the email address specified above.
			**********************
 This program is free software; you can redistribute it and/or modify
 it under the terms of the GNU General Public License as published by
 the Free Software Foundation; either version 2 of the License, or
 (at your option) any later version.
 
 This program is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 GNU General Public License for more details.

 You should have received a copy of the GNU General Public License
 along with this program; if not, write to the Free Software
 Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

***************************************************************************/

#include <stdio.h>     
#include <stdlib.h>    
#include <string.h>

#define SIZEBMP         1086
#define SIZELCD         1024

unsigned char  arrayLCD[SIZELCD], arrayBmp[SIZEBMP],arrayRotated[SIZELCD];

unsigned char comp_byte(int k,int j,unsigned char mask,int s)
/***********************************************************/
/****							****/
/**** Gets the correct bits from the rotated array	****/
/****  and compiles them in the output array		****/
/****							****/
/***********************************************************/
{
	return (	(((  arrayRotated[k+j]    & mask ) << s ) >> 7 )  |
			(((  arrayRotated[k+j+16] & mask ) << s ) >> 6 )  |
			(((  arrayRotated[k+j+32] & mask ) << s ) >> 5 )  |
			(((  arrayRotated[k+j+48] & mask ) << s ) >> 4 )  |
			(((  arrayRotated[k+j+64] & mask ) << s ) >> 3 )  |
			(((  arrayRotated[k+j+80] & mask ) << s ) >> 2 )  |
			(((  arrayRotated[k+j+96] & mask ) << s ) >> 1 )  |
			((   arrayRotated[k+j+112]& mask ) << s ) )  ;
}

void convert_1bpp()
/***********************************************************/
/****							****/
/**** Converts from the single BMP array into the	****/
/****  output array					****/
/**** This function converts a 1 bpp BMP only		****/
/****							****/
/***********************************************************/
{
int i,k,j,f;
       /* Re-order the bmp and set the correct black value */
	for(i=0;i<SIZELCD;i+=16)
		for(j=0;j<16;j++)
			arrayRotated[i+j]=~arrayBmp[SIZEBMP-i-16+j];
	/* Now ( ugly ) set the params for the comp_byte and call it 128 times */
	j = 0;
	k = 0;
	for(i=0;i<SIZELCD;i+=8)
	{
		for(f=0;f<8;f++)
			arrayLCD[i+f] = comp_byte(k,j,(1<<7)-f,f);
		j++;
		if ( j==16 )
		{
			k += 128;
			j = 0;
		}
	}
}

void helpfunc(void)
/***********************************************************/
/****							****/
/**** Displays help and exit				****/
/****							****/
/***********************************************************/
{
	printf("Usage : bmp2lcd <file in> <file out> [c array name]\n");
	printf("If [c array name] is not given, defaults to <Splash>\n");
	exit(0);
}

void bmp_summary(void)
/***********************************************************/
/****							****/
/**** Displays the BMP summary				****/
/**** This function exits if not 1bpp or resolution is 	****/
/****  wrong						****/
/****							****/
/***********************************************************/
{
	printf("Bmp summary:\n");
	printf("	Width    : %i\n",arrayBmp[18]);
	printf("	Height   : %i\n",arrayBmp[22]);
	printf("	BitPlane : %i\n",arrayBmp[26]);
	printf("	Bpp      : %i\n",arrayBmp[28]);
	printf("	Colors   : %i\n\n",arrayBmp[28]*arrayBmp[28]);

	if ( arrayBmp[28] != 1 )
	{
		printf("Colors is not 1, exiting\n");
		exit(1);
	}
	if ( arrayBmp[18] != 128 )
	{
		printf("Width is not 128, exiting\n");
		exit(1);
	}
	if ( arrayBmp[22] != 64 )
	{
		printf("Height is not 64, exiting\n");
		exit(1);
	}
}

int main (int argc, char *argv[])
/***********************************************************/
/****							****/
/**** Main						****/
/****							****/
/***********************************************************/
{
FILE *fp;
int i,k,line,result;

	printf("bmp2lcd V 1.0\n");
	printf("Bmp image to 128x64 LCD module converter\n");
	printf("By Fil (shinymetal@libero.it), 2003\n\n");

	if ( argc > 4 )
		helpfunc();
	if ( argc == 1 )
		helpfunc();

	if ( (fp = fopen( argv[1] , "rb")) == NULL)
	{
		fprintf(stderr, "Error opening INPUT file %s.\n",argv[1]);
		exit(1);
	}
	/* Read the bitmap into arrayBmp[]. */

	if ((result=fread(arrayBmp,sizeof(unsigned char),SIZEBMP,fp)) != SIZEBMP)
	{
		fprintf(stderr, "Error reading file %s\n",argv[1]);
		fprintf(stderr,"Length is %i\n",result);
		exit(1);
	}
	fclose(fp);

	bmp_summary();

	/* Open the output file. */

	if ( (fp = fopen(argv[2], "w")) == NULL)
	{
		fprintf(stderr, "Error opening OUTPUT file %s.\n",argv[2]);
		exit(1);
	}

	printf("The c arrays will be named ");
	if ( argc == 4 )
		printf("%s_left[] and %s_right\n",argv[3],argv[3]);
	else
		printf("Splash_left[] and Splash_right\n");
	printf("\nFile %s opened\nConvertion started... ",argv[2]);

	convert_1bpp();

	fprintf(fp,"/* Automagically generated with bmp2lcd V 1.0 */\n");
	fprintf(fp,"/* By Fil (shinymetal@libero.it), 2003 */\n");
	fprintf(fp,"\n\n");
	fprintf(fp,"/* Left half of the LCD */\n\n");
	fprintf(fp,"const unsigned char ");
	if ( argc == 4 )
		fprintf(fp,"%s_left[] = {\n",argv[3]);
	else
		fprintf(fp,"Splash_left[] = {\n");
	line = 0;

	for(i=0;i<SIZELCD;i+=128)
	{
		for(k=0;k<64;k++)
		{
			if ( (k==63) & (i==SIZELCD-128) )
				fprintf(fp,"0x%x",arrayLCD[i+k]);
			else
				fprintf(fp,"0x%x,",arrayLCD[i+k]);
		}
		if ( 	(i==0) | (i==128) | (i==256) | (i==384) | 
			(i==512) |  (i==640) | (i==768) | (i==896) )
			fprintf(fp," /* Line %i */\n",line++);
		else
			fprintf(fp,"\n");
	}
	fprintf(fp,"};\n\n");

	fprintf(fp,"/* Right half of the LCD */\n\n");
	fprintf(fp,"const unsigned char ");
	if ( argc == 4 )
		fprintf(fp,"%s_right[] = {\n",argv[3]);
	else
		fprintf(fp,"Splash_right[] = {\n");
	line = 0;
	for(i=0;i<SIZELCD;i+=128)
	{
		for(k=64;k<128;k++)
		{
			if ( (k==127) & (i==SIZELCD-128) )
				fprintf(fp,"0x%x",arrayLCD[i+k]);
			else
				fprintf(fp,"0x%x,",arrayLCD[i+k]);
		}
		if ( 	(i==0) | (i==128) | (i==256) | (i==384) | 
			(i==512) |  (i==640) | (i==768) | (i==896) )
			fprintf(fp," /* Line %i */\n",line++);
		else
			fprintf(fp,"\n");
	}
	fprintf(fp,"};\n\n");

	fclose(fp);
	printf("Convertion finished\n");
	return(1);
}
