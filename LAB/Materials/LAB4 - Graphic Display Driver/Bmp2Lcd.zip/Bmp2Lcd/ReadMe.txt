bmp2lcd: BMP coded graphic file to 128X64 LCD module C source converter.
Copyright (C) 2003 shinymetal@libero.it

bmp2lcd.zip contains the following:

bmp2lcd.c	:	bmp2lcd.exe source code
bmp2lcd.exe	:	DOS executable, BorlandTC compiled
font.c		:	font c code
Makefile	:	Makefile for Linux
banshee2.bmp	:	sample image ( my os splash )
Copyright.txt	:	GNU GENERAL PUBLIC LICENSE

Please note that this code works ONLY with a 1bpp BMP image.

bmp2lcd converts from a 1bpp BMP coded image into a C source code
 composed of two arrays, one for the left half and the other one for
 the right half of the LCD module.
As an additional option, you can specify the array name ( defaults to
 Splash ).
If you find any bug or you have some suggestions, feel free to
 write me at the email address specified above.

The code has been tested on WindowsME, WindowsXP and Linux.

Included in the zip file, the "font.c" code is the fonts file  I'm actually
 using.
I've found at www.skippari.net the "fonts.c" file from 
 Gregor Horvat (grega@silon.si), and I've modified his code adding all the
 low ascii codes.

Usage : bmp2lcd <file in> <file out> [c array name]
If [c array name] is not given, defaults to <Splash>
