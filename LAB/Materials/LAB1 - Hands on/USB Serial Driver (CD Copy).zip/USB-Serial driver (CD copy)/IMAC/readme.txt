Release Note, PL2303 Mac OS 8/9 driver v1.3.6 build 1, Prolific Edition
==================================================
 
Requirement:
. MacOS 8/9
. USB host controller
. Device using PL-2303H or PL-2303X
 
Supported device ID and descriptions:
    VID_067B&PID_2303, "PL-2303"
    VID_067B&PID_04BB, "IO-DATA"
 
Changes from v1.3.5b2:
. BugFix: The chip detection(H or X) was not correct, it introduced data transfer problems.
 
 
==================================================
Prolific Technology Inc. 
http://tech.prolific.com.tw
 

